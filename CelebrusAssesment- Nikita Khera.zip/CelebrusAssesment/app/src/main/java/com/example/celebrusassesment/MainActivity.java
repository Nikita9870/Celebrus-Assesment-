package com.example.celebrusassesment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.EditText;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class MainActivity<Button1> extends AppCompatActivity implements NewsAPIManager.NewsListener {
    private EditText keywordEditText;
    private Button1 findButton;
    private RecyclerView recyclerView;
    private NewsAdapter newsAdapter;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        keywordEditText = findViewById(R.id.EditText);
        findButton = (Button1) findViewById(R.id.Button1);
        recyclerView = findViewById(R.id.recyclerView);

        findButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String keyword = keywordEditText.getText().toString();
                // Get the current date in the required format
                String date = // Implement logic to get the current date;

                        NewsAPIManager.searchNews(keyword, date, MainActivity.this);
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    @Override
    public void onNewsFetched(String result) {
        List<News> newsList = new ArrayList<>();

        try {
            JSONObject jsonObject = new JSONObject(result);
            JSONArray articles = jsonObject.getJSONArray("articles");

            for (int i = 0; i < articles.length(); i++) {
                JSONObject article = articles.getJSONObject(i);

                String title = article.getString("title");
                String description = article.getString("description");
                String url = article.getString("url");

                News news = new News(title, description, url);
                newsList.add(news);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        newsAdapter = new NewsAdapter(newsList);
        recyclerView.setAdapter(newsAdapter);
    }
}
