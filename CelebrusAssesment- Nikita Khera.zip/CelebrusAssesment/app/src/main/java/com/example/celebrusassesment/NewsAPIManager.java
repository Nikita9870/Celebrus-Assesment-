package com.example.celebrusassesment;
import android.os.AsyncTask;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class NewsAPIManager {
    private static final String API_KEY = " 710119f4520a4c25b4ab12e46322e7db\n";

    public interface NewsListener {
        void onNewsFetched(String result);
    }

    public static void searchNews(String keyword, String date, NewsListener listener) {
        new NewsAsyncTask(listener).execute(keyword, date);
    }

    private static class NewsAsyncTask extends AsyncTask<String, Void, String> {
        private final NewsListener listener;

        public NewsAsyncTask(NewsListener listener) {
            this.listener = listener;
        }

        @Override
        protected String doInBackground(String... params) {
            String keyword = params[0];
            String date = params[1];

            try {
                URL url = new URL("https://newsapi.org/v2/everything?q=" + keyword +
                        "&from=" + date + "&language=en&apiKey=" + API_KEY);

                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder result = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }

                reader.close();
                connection.disconnect();

                return result.toString();

            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (listener != null) {
                listener.onNewsFetched(result);
            }
        }
    }
}
