package com.example.celebrusassesment;

public class News {
    private String title;
    public String getTitle() {
        return title;
    }
    private String description;
    private String url;

    public News(String title, String description, String url) {
        this.title = title;
        this.description = description;
        this.url = url;
    }


    // Constructor, getters, and setters
}


    // Other methods and properties...